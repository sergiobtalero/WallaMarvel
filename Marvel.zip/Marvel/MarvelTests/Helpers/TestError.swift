//
//  TestError.swift
//  Marvel
//
//  Created by Sergio David Bravo Talero on 1/4/25.
//

import Foundation

struct TestError: Error {
    let description: String
}
