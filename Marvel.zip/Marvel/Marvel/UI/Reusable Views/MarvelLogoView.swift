//
//  MarvelLogoView.swift
//  Marvel
//
//  Created by Sergio David Bravo Talero on 1/4/25.
//

import SwiftUI

struct MarvelLogoView: View {
    var body: some View {
        Image("Marvel-Logo")
            .resizable()
    }
}
